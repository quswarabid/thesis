function [num_iters] = findMaxIters(adj_mat)
    N = size(adj_mat(:,1));
    num_iters = N;
    adj_mat_temp  = adj_mat;
    for iter=1:num_iters
        adj_mat = adj_mat_temp;
        %discount_factor = (exp(-.1*iter));
        for i=1:N
            for j=1:N
                max_iterant = -inf;
                for k=1:N
                    if i~=j
                        new_iterant = (adj_mat(i,k) + adj_mat(k,j));
                        if max_iterant < new_iterant
                            max_iterant = new_iterant;
                        end
                    end
                end
                if adj_mat_temp(i,j) < max_iterant
                    adj_mat_temp(i,j) = max_iterant;
                end
            end
        end
    end
    
    num_iters = max(max(adj_mat_temp))
end

