function [edr,w,EEd,ed]=my_check_test(distance,rel_mat)
% used in obtain reslt from my method 
%%
% clc
% clear all
% close all



%% relaibality  

%%
% distance=dlmread('distances10.txt'); %% change it
% rel_mat=dlmread('tenth.txt'); %% only change name (next)
N=length(distance);

range_distance=distance;
for i=1:N
    for j=1:N
        if(distance(i,j)>=5)  %% change it after 2 
            range_distance(i,j)=0;
        end
    end
end
range_distance;

%%
my_rel_mat=rel_mat;
for i=1:N
    for j=1:N
        if(range_distance(i,j)~=0 & distance(j,N)>=distance(i,N))
            my_rel_mat(i,j)=0;
        end
    end
end
my_rel_mat(N,N)=1;
rel_mat=my_rel_mat;
%%
Distinct=zeros(N);
for i=1:N
    for j=1:N
        if(rel_mat(i,j)~=0)
            s=0;
            for k=j+1:N
                if(rel_mat(i,k)==0 && rel_mat(j,k)~=0)
                    s=s+rel_mat(j,k);
                end
            end
            Distinct(i,j)=s;
        end
    end
end

Distinct;
%%

common=zeros(N);
for i=1:N
    for j=1:N
        if(rel_mat(i,j)~=0)
            s=0;
            for k=j+1:N
                if(rel_mat(i,k)~=0 && rel_mat(j,k)~=0)
                    s=s+rel_mat(j,k);
                end
            end
            total_n_s=sum(rel_mat(j,:));
%             s
            common(i,j)=s/total_n_s;
             if(common(i,j)==0)
                common(i,j)=2;
            end
        end
    end
end

for i=1:N
    for j=1:N
        if(common(i,j)~=0)
            common(i,j)=abs(1-common(i,j));
        end
    end
end

common;

%%
Distance_ratio=zeros(N);
for i=1:N
    for j=1:N
        if(rel_mat(i,j)~=0)
            ratio=distance(j,N)/distance(i,N);
            Distance_ratio(i,j)=ratio;
        end
    end
end
Distance_ratio;


for i=1:N
    for j=1:N
        if(Distance_ratio(i,j)~=0)
            Distance_ratio(i,j)=1-Distance_ratio(i,j);
        end
    end
end

Distance_ratio(:,N)=0;
Distance_ratio;
%%

z=rel_mat.*Distinct.*common.*Distance_ratio;
z(:,N)=rel_mat(:,N);
z;
p=z;
for i=1:N
    row_s=sum(z(i,:));
    for j=1:N
        p(i,j)=z(i,j)/row_s;
    end
end
p;
for jj=1:N
if(isnan(p(jj,1)))
p(jj,:)=0;
end
end
p;


% v1=p(1:N-1,1:N-1);
v1=p.*rel_mat;
% v=v1.*v2;
r=v1(1:N-1,N:N);
v=v1(1:N-1,1:N-1);
i=eye(N-1,N-1);
q=i-v;
w=inv(q)*r;

edr=sum(w)/(N-1); %EDR_avg
w(1); %edr_s 

%%
Q=p(1:N-1,1:N-1);

one=ones(N-1,1);
ed=inv(i-Q)*one;
EEd=sum(ed)/N-1; %edd_avg
ed(1); %edd_s
end
        
 
        
        