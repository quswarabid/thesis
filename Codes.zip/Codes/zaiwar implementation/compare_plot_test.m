clc
clear all
close all
% %% shows results of conference paper 
result_for_randomWalk=[ 
  %number of  Edr_avg    Edr_s
    %nodes  
   25.0000    0.2022    0.0522
   45.0000    0.1532    0.0315
   65.0000    0.1482    0.0348
   85.0000    0.0773    0.0165
  105.0000    0.0786    0.0171
  125.0000    0.0859    0.0173
  145.0000    0.0532    0.0127
  165.0000    0.0623    0.0144
  185.0000    0.0461    0.0092
  205.0000    0.0761    0.0159];

r1=result_for_randomWalk; 
%*****************************
result_for_randomWalk2=[ 
 %number of   Edd_avg   Edd_s
   %nodes
   25.0000    2.2496    5.7387
   45.0000    2.8743    5.6100
   65.0000    3.1103    6.2273
   85.0000    3.5683    6.7364
  105.0000    3.5398    6.5724
  125.0000    3.7820    7.0930
  145.0000    3.9581    6.9676
  165.0000    4.0301    7.0811
  185.0000    4.1130    7.2009
  205.0000    4.2709    7.4036];

rr1=result_for_randomWalk2;

%%
result_for_Lij=[
   %number of  Edr_avg    Edr_s
    %nodes 
   25.0000    0.2912    0.1089
   45.0000    0.2392    0.0858
   65.0000    0.2513    0.1110
   85.0000    0.1675    0.0694
  105.0000    0.1605    0.0720
  125.0000    0.1699    0.0661
  145.0000    0.1070    0.0456
  165.0000    0.1231    0.0527
  185.0000    0.1036    0.0422
  205.0000    0.1838    0.0742];
% 
r2=result_for_Lij;
%********************
result_for_Lij2=[ 
  %number of   Edd_avg   Edd_s
   %nodes
   25.0000    2.2993    5.8555
   45.0000    2.7847    5.4783
   65.0000    3.1746    6.2564
   85.0000    3.4153    6.5958
  105.0000    3.4459    6.4803
  125.0000    3.7533    7.0619
  145.0000    3.8625    6.8835
  165.0000    4.0149    7.0487
  185.0000    4.0906    7.1886
  205.0000    4.4446    7.5656];

rr2=result_for_Lij2;

%%
result_for_relia_expender=[  
   %number of  Edr_avg    Edr_s
    %nodes 
   25.0000    0.4464    0.3248
   45.0000    0.4161    0.2597
   65.0000    0.4076    0.2615
   85.0000    0.3760    0.1905
  105.0000    0.3447    0.1907
  125.0000    0.3623    0.1999
  145.0000    0.2861    0.1632
  165.0000    0.3666    0.2122
  185.0000    0.3800    0.2108
  205.0000    0.3395    0.1874];

r3=result_for_relia_expender;
%****************
result_for_relia_expender2=[
  %number of   Edd_avg   Edd_s
   %nodes
   25.0000    0.7936    3.3980
   45.0000    1.3239    3.3567
   65.0000    1.0422    3.4515
   85.0000    1.1725    3.5618
  105.0000    1.2107    3.6441
  125.0000    0.9909    3.5651
  145.0000    1.3088    3.6189
  165.0000    1.2670    3.6274
  185.0000    1.0674    3.4901
  205.0000    1.2122    3.6900];

rr3=result_for_relia_expender2;


%%
result_for_my_method=[
   %number of  Edr_avg    Edr_s
    %nodes 
   25.0000    0.4682    0.1907
   45.0000    0.4198    0.2558
   65.0000    0.4174    0.2679
   85.0000    0.4082    0.2042
  105.0000    0.3853    0.2609
  125.0000    0.3902    0.2149
  145.0000    0.3260    0.2000
  165.0000    0.3941    0.2376
  185.0000    0.3980    0.2228
  205.0000    0.3663    0.2191];

r4=result_for_my_method;
%******************************
result_for_my_method2=[
 %number of   Edd_avg   Edd_s
   %nodes
   25.0000    0.6618    3.0491
   45.0000    1.0910    3.0919
   65.0000    0.8558    3.1563
   85.0000    0.8963    3.1485
  105.0000    0.9488    3.2098
  125.0000    0.7977    3.2037
  145.0000    1.0429    3.1927
  165.0000    0.9504    3.1852
  185.0000    0.8544    3.1633
  205.0000    0.9286    3.2402];

rr4=result_for_my_method2;

%% EDRav
x=r1(:,1); % assigning first column of random walkig result (i.e. number of nodes) to x
y1=r1(:,2); % assigning second column of Random walking result of Edr_avg to y1
y2=r2(:,2);% assigning second column of Lij routing result of Edr_avg to y2
y3=r3(:,2);% assigning second column of reliability expander result of Edr_avg to y3
y4=r4(:,2);% assigning second column of Zij routing result of Edr_avg to y4

%%
m1='Random Walking';
m2='L_{ij} Routing Method';
m3='Reliability Expender';
m4='Z_{ij} Routing Technique';
%plotting average expected delivery ratio of all the methods
plot(x,y1,'k--s',x,y2,'m--o',x,y3,'r--*',x,y4,'b--^','MarkerSize',10,'LineWidth',2);
title('Average Expected Delivery Ratio')% setting the title of the graph
xlabel('Number of Nodes') % x-axis
ylabel('\itEDR_{avg}') %y-axis
legend({m1,m2,m3,m4},'FontSize',10,'FontWeight','bold');

%% EDRs
g1=r1(:,3);% assigning third column of Random walking result of Edr_s to g1
g2=r2(:,3);% assigning third column of Lij routing result of Edr_s to g2
g3=r3(:,3);% assigning third column of Reliability expender result of Edr_s to g3
g4=r4(:,3);% assigning third column of Zij routing result of Edr_s to g4
figure % plot graph on seperate figure
%plotting expected delivery ratio from source to destination
plot(x,g1,'k--s',x,g2,'m--o',x,g3,'r--*',x,g4,'b--^','MarkerSize',10,'LineWidth',2);
title('From Source to Distination Expected Delivery Ratio')
xlabel('Number of Nodes')
ylabel('\itEDR_s')
legend({m1,m2,m3,m4},'FontSize',10,'FontWeight','bold')

%% EDDav
yy1=rr1(:,2); % assigning second column of Random walking result of Edd_avg to yy1
yy2=rr2(:,2);% assigning second column of Lij routing result of Edd_avg to yy2
yy3=rr3(:,2);% assigning second column of reliability expander result of Edd_avg to yy3
yy4=rr4(:,2);% assigning second column of Zij routing result result of Edd_avg to yy4
%plotting average expected delivery dealy 
figure
plot(x,yy1,'k--s',x,yy2,'m--o',x,yy3,'r--*',x,yy4,'b--^','MarkerSize',10,'LineWidth',2);
title('Average Expected Delivery Delay')
xlabel('Number of Nodes')
ylabel('{\itEDD_{avg}} (routed nodes)')
legend({m1,m2,m3,m4},'FontSize',10,'FontWeight','bold','Location','northwest')

%% EDDs
gg1=rr1(:,3); % assigning third column of Random walking result of Edd_s to gg1
gg2=rr2(:,3);% assigning third column of Lij routing result of Edd_s to gg2
gg3=rr3(:,3);% assigning third column of Reliability expander result of Edd_s to gg3
gg4=rr4(:,3);% assigning third column of Zij routing result of Edd_s to gg4
%plotting expected delivery delay from source to destination
figure
h1=plot(x,gg1,'k--s',x,gg2,'m--o',x,gg3,'r--*',x,gg4,'b--^','MarkerSize',10,'LineWidth',2);
title('From Source to Distination Expected Delivery Delay')
xlabel('Number of Nodes')
%ylabel('E_{dd_s}')
ylabel('{\itEDD_s} (routed nodes)')
legend({m1,m2,m3,m4},'FontSize',10,'FontWeight','bold','Location','northwest')


