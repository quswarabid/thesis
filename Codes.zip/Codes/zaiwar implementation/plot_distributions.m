x1 = 0:10:10000
x2 = 0:1:10000

y1=rand(1,1001)
y2=rand(1,10001)

plot (x1,y1)



r = normrnd(10,1,10000000,1);
histfit(r)
r = normrnd(10,1,100000,1);
histfit(r)
r = normrnd(10,1,10000,1);
histfit(r)
