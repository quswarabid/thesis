function [edr,w,EEd,ed] = untitled(distance,rel_mat)

%
% Reliability expander function....
%

%%
% clc
% clear all
% close all
% 
% distance=dlmread('distance205.txt'); %% change it
% rel_mat=dlmread('rel_mat205.txt'); %% only change name (next)
N=length(distance);

%%
Distinct=zeros(N);
for i=1:N
    for j=1:N
        if(rel_mat(i,j)~=0)
            s=0;
            for k=j+1:N
                if(rel_mat(i,k)==0 && rel_mat(j,k)~=0)
                    s=s+rel_mat(j,k);
                end
            end
            Distinct(i,j)=s;
        end
    end
end
Distinct;

%%
common=zeros(N);
for i=1:N
    for j=1:N
        if(rel_mat(i,j)~=0)
            s=0;
            for k=j+1:N
                if(rel_mat(i,k)~=0 && rel_mat(j,k)~=0)
                    s=s+rel_mat(j,k);
                end
            end
            total_n_s=sum(rel_mat(j,:));
%             s
            common(i,j)=s/total_n_s;
        end
    end
end

for i=1:N
    for j=1:N
        if(common(i,j)~=0)
            common(i,j)=1-common(i,j);
        end
    end
end
common;
%%
z=rel_mat.*Distinct.*common;
z(:,N)=rel_mat(:,N);
z;
p=z;
for i=1:N
    row_s=sum(z(i,:));
    for j=1:N
        p(i,j)=z(i,j)/row_s;
    end
end
% p(:,N)=rel_mat(:,N);
p;
for jj=1:N
if(isnan(p(jj,1)))
p(jj,:)=0;
end
end
p;


% v1=p(1:N-1,1:N-1);
v1=p.*rel_mat;
% v=v1.*v2;
r=v1(1:N-1,N:N);
v=v1(1:N-1,1:N-1);
i=eye(N-1,N-1);
q=i-v;
w=inv(q)*r;

edr=sum(w)/(N-1) %edr_avg
w(1) %edr_s

%%
Q=p(1:N-1,1:N-1);

one=ones(N-1,1);
ed=inv(i-Q)*one;
EEd=sum(ed)/N-1; %edd_avg
EEd;
ed(1); %edd_s
end      
%%           
        
% fid = fopen('results2.txt','at');
%     fprintf(fid,'\n');
%     fprintf(fid,'Newnumber of nodes for present:    ');
%     fprintf(fid,'%g\t',N);
%     fprintf(fid,'\n');
%     fprintf(fid,'\n');
%     fprintf(fid,'EDRavrg:    ');
%     fprintf(fid,'%g\t',edr);
%     fprintf(fid,'\n');
%     fprintf(fid,'\n');
%     fprintf(fid,'W(1):      ');
%     fprintf(fid,'%g\t',w(1));
%     fprintf(fid,'\n');
%     fprintf(fid,'***************************************');        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
