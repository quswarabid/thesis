clc; clear all; close all;

%totalHops = [];
%for prog = 1:100
    
N=25;

%% Intitial setup for locations of IoT nodes

n=N; % n = total number of devices
R=6; % represents the closeness (R kam hoga to connected neighbores and distance zaida hun gai)
coverage = R; 

t = 2*pi*rand(n,1);
r = R*sqrt(rand(n,1));
x = r.*cos(t); % column vector containing x-coordinates of all the devices, generated randomly
y = r.*sin(t); % column vector containing y-coordinates of all the devices, generated randomly

x(1)=-R*cos(45*pi/180); % x coordinate of 1st device
y(1)=-R*sin(45*pi/180); % y coordinate of last device
%x(2)=-R*cos(45*pi/180); % x coordinate of 1st device
%y(2)=R*sin(45*pi/180); % y coordinate of last device
%x(3)=R*cos(45*pi/180); % x coordinate of 1st device
%y(3)=-R*sin(45*pi/180); % y coordinate of last device
%x(end-1)=10*R*cos(45*pi/180);% x coordinate of last device
%y(end-1)=10*R*sin(45*pi/180); %y coordinate of last device
x(end)=R*cos(45*pi/180);% x coordinate of last device
y(end)=R*sin(45*pi/180); %y coordinate of last device

coordinates=[x y]; % coordinates of all the devices
 
%% plot it
plot(x,y,'o','markersize',12) % plot the graph of all the devices
hold on
axis([-R-1 R+1 -R-1 R+1])

%% to find the farthermost coordinate,
%  i.e. the geogrphical distance of each node from destination
distance_from_destination = zeros(1,N);
x2=coordinates(N,1); % x-coordinate of destination
y2=coordinates(N,2); % y-coordinate of destination
for i=1:N
    x1=coordinates(i,1); % x-coordinate of ith device
    y1=coordinates(i,2); % y-coordinate of ith device
    % finding the distance of evry node from the destination and store in array
    distance_from_destination(i)=sqrt(((x2-x1)^2)+((y2-y1)^2));     
end

%% sort in decending order of distance from last coordinate (i.e. destination)
%update: don't need to do that now (13/09/2021)
%dfd=distance_from_destination; % assign distance_from_destination to dfd
%M1=coordinates;
%for i=1:N
%    [dis,indx]=max(dfd); % findng the maximum distance in dfd array, returning the 
%                         % value and index.
%    dfd(indx)=-inf;
%    M2(i,:)=[i M1(indx,1) M1(indx,2)]; % storing the distance of ith device from destination
%end
%M1; % coordinates of the nodes
%M2; % sorted distance 

%% to find distance between each pair of nodes
distance=ones(N);
for i=1:N
    x1=coordinates(i,1); % x-coordinate of first device
    y1=coordinates(i,2); % y-coordinate of first device
    for j=1:N
        x2=coordinates(j,1); % x-coordinate of second device
        y2=coordinates(j,2); % y-coordinate of second device
        % distance of every pair of nodes with each other
        distance(i,j)=sqrt(((x2-x1)^2)+((y2-y1)^2));
    end
end
distance;

%% converting distance matrix to a symmetric martix
%update: don't need to do that now (13/09/2021)
%distance_symmetric = distance;
%for i=1:N
%    for j=1:N
%        distance_symmetric(j,i) = distance_symmetric(i,j);
%    end
%end
%distance = distance_symmetric;


%% to find the transmission links
range_distance=distance;
for i=1:N
    for j=1:N
        a=[];
        b=[];
        if(distance(i,j)>=coverage)
            range_distance(i,j)=inf;
        end
        %range_distance(j,i) = range_distance(i,j);
    end
end
distance;
range_distance;

%% giving random reliability to each link
rel_mat=zeros(N); % initialize link reliabilites to zeros (to avoid garbage values)
adj_mat = zeros(N);
for i=1:N
    for j=i:N % nested loop to generate link reliabilities of ith node with every other node
        if(range_distance(i,j)~=inf)
            rel_mat(i,j)=rand(1); %randomly generated link reliabilities
            adj_mat(i,j) = 1;
        end
        if i==j
            adj_mat(i,j) = 0;
        end
        % need to assign them symmetrically
        rel_mat(j,i) = rel_mat(i,j);
        adj_mat(j,i) = adj_mat(i,j);
    end
end

rel_mat;

%% residual energies

residual_energy = .5 + rand(N,1).*.5;


%% calculating a reward matrix
%reward_matrix = zeros(N);
%distance_inverse = 1./distance_from_destination; %find a better way to incorporate distances

%tpm =  rel_mat; %rel_mat; %distance.*adj_mat;
%reward_matrix = -range_distance.*tpm;


reward_matrix = -range_distance;
%reward_matrix = -adj_mat;

%for i=1:N
%    for j=1:N
%        if reward_matrix(i,j) ~= inf || reward_matrix(i,j) ~= 0
%            reward_matrix(i,j) = 1/reward_matrix(i,j);
%        end
%        if reward_matrix(i,j) == inf || reward_matrix(i,j) == -inf || reward_matrix(i,j) == 0
%            reward_matrix(i,j) = -inf;
%        end
%    end
%end

%reward_matrix = -range_distance.*tpm;
%for i=1:N
%    reward_matrix(:,i) = reward_matrix(:,i).*residual_energy;
%end



for i=1:N
    for j=1:N
        if i==j %|| reward_matrix(i,j) == 0
            reward_matrix(i,j)=-inf;
        end
        if isnan(reward_matrix(i,j)) %|| reward_matrix(i,j) ==0
            reward_matrix(i,j)=-inf;
        end
    end
end
%reward_matrix(1,1)=-1;
%reward_matrix(N,N)=1;
%% creating a Q-Table
%q_table = zeros(N);
%for i=1:N
%    for j=1:N
%        q_table(i,j) = -inf;
%    end
%end

%% initializing the Q-Table
%coping the initial reward matrix to q-table

%for i=1:N
%    for j=1:N
%        if reward_matrix(i,j) >= 0
%            q_table(i,j) = reward_matrix(i,j);
%        end
%        if i==j
%            q_table(i,j)=-inf;
%        end
%    end
%end

q_table = reward_matrix;

%% updating the q-table
%so that subsequent updates can iterate the rest entries of table

num_iters = N; %findMaxIters(adj_mat);
discount_factor = 1;
q_table_temp  = q_table;
max_iterant = -inf;
for iter=1:num_iters
%while (sum(sum(q_table-q_table_temp))<0.00001)
    q_table = q_table_temp;
    for i=1:N
        for j=1:N
            max_iterant = -inf;
            for k=1:N
                if i~=j
                    %max_iterant = (q_table(i,k) + q_table(k,j)*discount_factor);
                    new_iterant = (reward_matrix(i,k) + q_table(k,j)*discount_factor);%*rel_mat(i,j)
                    if max_iterant < new_iterant
                        %disp(i+", "+j+", "+k);
                        max_iterant = new_iterant;
                    end
                end
            end
            if q_table_temp(i,j) < max_iterant
                q_table_temp(i,j) = max_iterant;
            end
        end
    end
end


% route a message from source to destination

%source_node = coordinates(1,:)
%destination_node = coordinates(N,:)
%current_node = source_node

source_node = 1;
destination_node = N;
current_node = 1;

hops_count = 0;

path = [source_node];

while current_node ~= destination_node && hops_count<N
    if adj_mat(current_node,destination_node)==1
        current_node = destination_node;
        hops_count = hops_count + 1;
        path = [path current_node];
    else
        c1 = adj_mat(:,current_node)'.*q_table(destination_node,:);
        %c2 = q_table(:,current_node).*adj_mat(:,current_node);
        c2 = reward_matrix(:,current_node).*adj_mat(:,current_node);
        [arg,argmax] = max(c1'+c2);
        current_node = argmax;
        hops_count = hops_count + 1;
        path = [path current_node];
    end
end

hops_count
path

%totalHops = [totalHops hops_count];
%end
%plot(totalHops)