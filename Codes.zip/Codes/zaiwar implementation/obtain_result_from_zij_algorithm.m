readings=100;
for k=1:10
    if k==1
        distance=dlmread('distance25.txt');
        rel_mat=dlmread('rel_mat25.txt');
    elseif k==2
        distance=dlmread('distance45.txt');
        rel_mat=dlmread('rel_mat45.txt');
    elseif k==3
        distance=dlmread('distance65.txt');
        rel_mat=dlmread('rel_mat65.txt');
    elseif k==4
        distance=dlmread('distance85.txt');
        rel_mat=dlmread('rel_mat85.txt');
    elseif k==5
        distance=dlmread('distance105.txt');
        rel_mat=dlmread('rel_mat105.txt');
    elseif k==6
        distance=dlmread('distance125.txt');
        rel_mat=dlmread('rel_mat125.txt');
    elseif k==7
        distance=dlmread('distance145.txt');
        rel_mat=dlmread('rel_mat145.txt');
    elseif k==8
        distance=dlmread('distance165.txt');
        rel_mat=dlmread('rel_mat165.txt');
    elseif k==9
        distance=dlmread('distance185.txt');
        rel_mat=dlmread('rel_mat185.txt');
    elseif k==10
        distance=dlmread('distance205.txt');
        rel_mat=dlmread('rel_mat205.txt');
    end

[edr,w,EEd,ed]=my_check_test(distance,rel_mat);
result1(k,:)=[length(rel_mat) edr w(1)];
result2(k,:)=[length(rel_mat) EEd ed(1)];


[edr_re,w_re,EEd_re,ed_re]=untitled(distance,rel_mat);
result1_reliability_expender(k,:)=[length(rel_mat) edr_re w_re(1)];
result2_reliability_expender(k,:)=[length(rel_mat) EEd_re ed_re(1)];
end


result1
result2

result1_reliability_expender
result2_reliability_expender
