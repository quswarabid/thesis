clc;
clear all;
close all;

%array = [5,25,45,65,85,105,125,145,165,185,205,225];
%for i=1:length(array)
%N=array(i);  %% N = the ith device
N=25;  %% N = the ith device

%%
n=N; % n = total number of devices
R=6; % represents the closeness (R kam hoga to connected neighbores and distance zaida hun gai)

 t = 2*pi*rand(n,1);
 r = R*sqrt(rand(n,1));
 x = r.*cos(t); % column vector containing x-coordinates of all the devices, generated randomly
 y = r.*sin(t); % column vector containing y-coordinates of all the devices, generated randomly
 
 x(1)=-R*cos(45*pi/180); % x coordinate of 1st device
 y(1)=-R*sin(45*pi/180); % y coordinate of last device
 x(end)=R*cos(45*pi/180);% x coordinate of last device
 y(end)=R*sin(45*pi/180); %y coordinate of last device
 
 plot(x,y,'o','markersize',12) % plot the graph of all the devices
 hold on
 axis([-R-1 R+1 -R-1 R+1])
 
 coordinates=[x y]; % coordinates of all the devices
 
%%
% 1) select N which will represent the number of nodes in the network.
% 2) N is tra select krain hai k square root ki value puri aa saky. ?????
% 3) N is tra select krna hai k ye matrix ki shakal mai coordinates lai saky.
% 4) coornidate matix ka first column, node k number ko show krta hai, jbk 2nd
%    column x coordinate ko r 3rd coulm y coordinate ko represnt krta hai.
% 5) Aur phir har aik node aur es ka destination(last coordinate in coordinates matrix) 
%    k darmyan may distance find kiya hai in the form of an array ( distance form destination )
% 6) Destination say jis node ka bhi distance zyada hou ose hesab say nodes k numbering 
%    ho jathe hain. Es ka mtlb ye hain k ju bhi node destination say fasle per hou ( dhor)
%    hou ose node-1 and ju es k bad dhoor hou wo node-2 and so on.
% 7) Phir har two nodes k darmyan distance ko measures karthe hain aur aik matrix may save 
%    karthe hain name "distance" and aik text file may bhi save karthe hain os ko 
%    named distance.
%% to find the farthermost coordinate
x2=coordinates(N,1); % x-coordinate of destination
y2=coordinates(N,2); % y-coordinate of destination
for i=1:N
    x1=coordinates(i,1); % x-coordinate of ith device
    y1=coordinates(i,2); % y-coordinate of ith device
    
% finding the distance of evry node from the destination and store in array
    distance_from_destination(i)=sqrt(((x2-x1)^2)+((y2-y1)^2)); 
    
end
%% sort in decending order of distance from last coordinate (i.e. destination)
dfd=distance_from_destination; % assign distance_from_destination to dfd
M1=coordinates;
for i=1:N
    [dis,indx]=max(dfd); % findng the maximum distance in dfd array, returning the 
                         % value and index.
    dfd(indx)=-inf;
    M2(i,:)=[i M1(indx,1) M1(indx,2)]; % storing the distance of ith device from destination
end
M1; % coordinates of the nodes
M2; % sorted distance 

%% to find distance between each pair of nodes
distance=zeros(N);
for i=1:N
    x1=M2(i,2); % x-coordinate of first device, sorted w.r.t distance
    y1=M2(i,3); % y-coordinate of first device, sorted w.r.t distance
    for j=i+1:N
        x2=M2(j,2); % x-coordinate of second device, sorted w.r.t distance
        y2=M2(j,3); % y-coordinate of second device, sorted w.r.t distance
        
% distance of every pair of nodes with each other        
        distance(i,j)=sqrt(((x2-x1)^2)+((y2-y1)^2)); 
    end
end
distance;

%% to find the transmission links
range_distance=distance;
 ll=1;
for i=1:N
    for j=1:N
        a=[];
        b=[];
        if(distance(i,j)>=6)    %% change it ///////////////9999/////
            range_distance(i,j)=0; % putting zeros in the distance of two and more hop 
                                   % neighbors
%              if(ll==1)
%             
%             a=[M2(i,2) M2(j,2)];
%             b=[M2(i,3) M2(j,3)];
%             plot(a,b)
%              end
%              ll=ll+1;
        end
    end
end
range_distance; % used to calculate link reliabilities 

%% giving random reliability to each link
rel_mat=zeros(N); % initialize link reliabilites to zeros (to avoid garbage values)
for i=1:N
    for j=1:N % nested loop to generate link reliabilities of ith node with every other node
        if(range_distance(i,j)~=0)
            rel_mat(i,j)=rand(1); %randomly generated link reliabilities
            
        end
    end
end
rel_mat(N,N)=1; % link reliability of destination node is 1
rel_mat; %% L_ij

%% sum of link reliabilities (S_ij)
Distinct=zeros(N);
for i=1:N
    for j=1:N
        if(rel_mat(i,j)~=0) % checking the condition if L_ij is not zero
            s=0; % initializing sum to zero
            for k=j+1:N
     % reliabailites of those nodes which have zero reliability with ith
     % node
                if(rel_mat(i,k)==0 && rel_mat(j,k)~=0)
                    s=s+rel_mat(j,k); % sum of link reliabilities
                end 
            end
            Distinct(i,j)=s; 
        end
    end
end
Distinct; %S_ij
%% fraction of reliabilities (T_ij)

common=zeros(N);
for i=1:N
    for j=1:N
        if(rel_mat(i,j)~=0) % checking the condition if L_ij is not zero
            s=0; % initializing sum to zero
            for k=j+1:N
     
                if(rel_mat(i,k)~=0 && rel_mat(j,k)~=0)
                    s=s+rel_mat(j,k); % sum of reliabilities of common neighbors of ith and 
                                      % jth node
                end
            end
            total_n_s=sum(rel_mat(j,:)); % sum of reliabilities of jth node with its neighbors
%             s
            common(i,j)=s/total_n_s; % sum of reliabailites of those nodes which are common 
                                     % with the ith node
            if(common(i,j)==0) % checking if common neighbors b/w ith and jode node is zero
                common(i,j)=2; % assign "2" if fraction of reliabilities are zero
            end
        end
    end
end
common2=common;
for i=1:N
    for j=1:N
        if(common(i,j)~=0)% checking if common neighbors b/w ith and jode node is zero
            common2(i,j)=abs(1-common(i,j)); % taking absolute to have positve values and to 
                                             % avoid NaN and subtracitng
                                             % from 1 (proposed algorithm)
        end
    end
end

common2;
common=common2; % T_ij
%% Distance reatio (V_ij)
Distance_ratio=zeros(N);
for i=1:N
    for j=1:N
        if(rel_mat(i,j)~=0) % checking if reliability matrix is not zero
            ratio=distance(j,N)/distance(i,N); % distance ratio b/w jth and ith node
            Distance_ratio(i,j)=ratio;
        end
    end
end
Distance_ratio; %V_ij


for i=1:N
    for j=1:N
        if(Distance_ratio(i,j)~=0) % checking if distance ratio is not equal to zero
            Distance_ratio(i,j)=1-Distance_ratio(i,j); % subtracting the distance ratio from 1
                              % required in proposed algorithm
        end
    end
end

Distance_ratio(:,N)=0; % assigning zero to the distance ratio of destination node
Distance_ratio; %V_ij
%% Proposed Algorithm (Z_ij algorithm)

% z=L_ij * S_ij (1 - V_ij) (1 - T_ij)
z=rel_mat.*Distinct.*common.*Distance_ratio; 
z(:,N)=rel_mat(:,N); % assign last column of reliability matrix to the last column of z
z; % Z_ij algorithm
%% Transition probability of the links 
p=z;
for i=1:N 
    row_s=sum(z(i,:)); % sum of z
    for j=1:N
        p(i,j)=z(i,j)/row_s; % transition probability : p = z_ij/ sum of z
    end
end
p;
for jj=1:N
if(isnan(p(jj,1))) % checking if there is NaN in p
p(jj,:)=0; % assigning zero to the NaN in transition probability
end
end
p; % transition probability of all nodes

%%  expected delivery delay

c=p(1:N-1,1:N-1); % transient node reliabiliies
r=ones(N-1,1); 
i=eye(N-1,N-1); % identity matrix
f=inv(i-c); % fundamental matrix of P
w=f*r; % Expected delivery delay of all transient nodes to destination

edda=sum(w)/(N-1); % expected delivery delay average
edds=w(1); % ecpected delivery delay of source to destination
%% visualization

%nodes=1:N;
%mygraph1 = biograph(rel_mat,nodes,'ShowArrows','on','ShowWeights','on'); % graph showing 
                            % reliability matrix (i.e. L_ij) of all nodes

%set(mygraph1.nodes,'Shape','circle','FontSize',10) % setting the characteristics of graph

%h1 = view(mygraph1); % displayin the graph


%p;
%f;
%w;


%% to store files of link reliabilites and distance 
% manually change the name of the reliability matrix and distance
% matirx

% ############### saving files for reliability matrix ###################
 fid = fopen(strcat('rel_mat',string(N),'.txt'),'wt'); %% change it repectively after changing the number of iot devices at the top.... (i.e. N=25, N=45, .... , N=205)
  
  for ii = 1:size(rel_mat,1)
      fprintf(fid,'%g\t',rel_mat(ii,:));
      fprintf(fid,'\n');
  end

% #################### saving files for distance ################ 
 fid2 = fopen(strcat('distance',string(N),'.txt'),'wt'); %% change it
 
 for ii = 1:size(distance,1)
     fprintf(fid2,'%g\t',distance(ii,:));
     fprintf(fid2,'\n');
 end

 
 
%end