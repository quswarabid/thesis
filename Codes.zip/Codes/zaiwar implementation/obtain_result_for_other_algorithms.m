clc
clear all
close all
 % obtain results for Rij and random walk using check
readings=1;
for k=1:10
    if k==1
        % dimension of rrr1 25 x 25
        rel_mat=dlmread('rel_mat25.txt'); % dlmread = detects the delimiter from the file and treats 
                                     % repeated white spaces as a single delimiter.
    elseif k==2
        rel_mat=dlmread('rel_mat45.txt'); % dimension(rr2) = 45 x 45
    elseif k==3
        rel_mat=dlmread('rel_mat65.txt'); % dimension(third) = 65 x 65
    elseif k==4
        rel_mat=dlmread('rel_mat85.txt'); % dimension (fourth) = 85 x 85
    elseif k==5
        rel_mat=dlmread('rel_mat105.txt'); % dimension (rr5) = 105 x 105
    elseif k==6
        rel_mat=dlmread('rel_mat125.txt'); % dimension (sixth) = 125 x 125
    elseif k==7
        rel_mat=dlmread('rel_mat145.txt'); % dimension ( seventh) = 145 x 145
    elseif k==8
        rel_mat=dlmread('rel_mat165.txt'); % dimension (eight) = 165 x 165
    elseif k==9
        rel_mat=dlmread('rel_mat185.txt');% dimension (ninth) = 185 x 185
    elseif k==10
        rel_mat=dlmread('rel_mat205.txt'); % dimension (tenth) = 205 x 205
    end

%[edr,w,EEd,ed]=check(rel_mat);
[edr_rij,w_rij,EEd_rij,ed_rij] = Rij_algorithm_test(rel_mat);
[edr_randomwalk,w_randomwalk,EEd_randomwalk,ed_randomwalk] = random_walk_test(rel_mat);


result1_rij(k,:)=[length(rel_mat) edr_rij w_rij(1)];
result2_rij(k,:)=[length(rel_mat) EEd_rij ed_rij(1)];

result1_randomwalk(k,:)=[length(rel_mat) edr_randomwalk w_randomwalk(1)];
result2_randomwalk(k,:)=[length(rel_mat) EEd_randomwalk ed_randomwalk(1)];

end
result1_rij
result2_rij

result1_randomwalk
result2_randomwalk











