clc; clear all; close all;

N=25;

Average_edr_avg_over_mult_runs = 0;
Average_edd_avg_over_mult_runs = 0;

Average_edr_sd_over_mult_runs = 0;
Average_edd_sd_over_mult_runs = 0;

num_rounds = 100;

num_nodes = [25,45,65,85,105,125,145,165,185,205];

result_for_my_method_quswar = [];
result_for_my_method2_quswar = [];

for all_num_nodes = 1:length(num_nodes)
    


for rounds = 1:num_rounds 

%% Intitial setup for locations of IoT nodes
N=num_nodes(all_num_nodes)
n=N; % n = total number of devices
R=6; % represents the closeness (R kam hoga to connected neighbores and distance zaida hun gai)
coverage = R;

t = 2*pi*rand(n,1);
r = R*sqrt(rand(n,1));
x = r.*cos(t); % column vector containing x-coordinates of all the devices, generated randomly
y = r.*sin(t); % column vector containing y-coordinates of all the devices, generated randomly

x(1)=-R*cos(45*pi/180); % x coordinate of 1st device
y(1)=-R*sin(45*pi/180); % y coordinate of last device
%x(2)=-R*cos(45*pi/180); % x coordinate of 1st device
%y(2)=R*sin(45*pi/180); % y coordinate of last device
%x(3)=R*cos(45*pi/180); % x coordinate of 1st device
%y(3)=-R*sin(45*pi/180); % y coordinate of last device
%x(end-1)=10*R*cos(45*pi/180);% x coordinate of last device
%y(end-1)=10*R*sin(45*pi/180); %y coordinate of last device
x(end)=R*cos(45*pi/180);% x coordinate of last device
y(end)=R*sin(45*pi/180); %y coordinate of last device

coordinates=[x y]; % coordinates of all the devices
 
%% plot it
%plot(x,y,'o','markersize',12) % plot the graph of all the devices
%hold on
%axis([-R-1 R+1 -R-1 R+1])

%% to find the farthermost coordinate,
%  i.e. the geogrphical distance of each node from destination
distance_from_destination = zeros(1,N);
x2=coordinates(N,1); % x-coordinate of destination
y2=coordinates(N,2); % y-coordinate of destination
for i=1:N
    x1=coordinates(i,1); % x-coordinate of ith device
    y1=coordinates(i,2); % y-coordinate of ith device
    % finding the distance of evry node from the destination and store in array
    distance_from_destination(i)=sqrt(((x2-x1)^2)+((y2-y1)^2));     
end


%% to find distance between each pair of nodes
distance=ones(N);
for i=1:N
    x1=coordinates(i,1); % x-coordinate of first device
    y1=coordinates(i,2); % y-coordinate of first device
    for j=1:N
        x2=coordinates(j,1); % x-coordinate of second device
        y2=coordinates(j,2); % y-coordinate of second device
        % distance of every pair of nodes with each other
        distance(i,j)=sqrt(((x2-x1)^2)+((y2-y1)^2));
    end
end
distance;


%% to find the transmission links
range_distance=distance;
for i=1:N
    for j=1:N
        a=[];
        b=[];
        if(distance(i,j)>=coverage)
            range_distance(i,j)=inf;
        end
    end
end
distance;
range_distance;

%% giving random reliability to each link
rel_mat=zeros(N); % initialize link reliabilites to zeros (to avoid garbage values)
adj_mat = zeros(N);
one_by_rel_mat=zeros(N);
for i=1:N
    for j=i:N % nested loop to generate link reliabilities of ith node with every other node
        if(range_distance(i,j)~=inf)
            rel_mat(i,j)=rand(1); %randomly generated link reliabilities
            one_by_rel_mat(i,j)=1/rel_mat(i,j);
            adj_mat(i,j) = 1;
        end
        if i==j
            adj_mat(i,j) = 0;
            rel_mat(i,j) = 0;
        end
        % need to assign them symmetrically
        rel_mat(j,i) = rel_mat(i,j);
        adj_mat(j,i) = adj_mat(i,j);
        one_by_rel_mat(i,j)=one_by_rel_mat(j,i);
    end
end

rel_mat;

%% residual energies

residual_energy = rand(N,1);

energy_ratio = zeros(N);

one_by_energy_ratio = zeros(N);

for i=1:N
    for j=1:N
        energy_ratio(i,j) = (residual_energy(i,1))^1 * residual_energy(j,1);
        energy_ratio(i,j) = energy_ratio(i,j)/(1*1);
        one_by_energy_ratio(i,j) = 1/energy_ratio(i,j);
    end
end

%% distance matrix

distance_matrix = zeros(N);

for i=1:N
    for j=1:N
        distance_matrix(i,j) = 1/range_distance(i,j);
    end
end

%% two way reliability factor for a given link

two_way_rel_mat = zeros(N);
one_by_two_way_rel_mat = zeros(N);

for i=1:N
    for j=1:N
        % first, distinct neighbors of i and j
        distinct_neighbors_of_i_and_j = xor(adj_mat(:,i),adj_mat(:,j));
        distinct_neighbors_of_i_wrt_j = distinct_neighbors_of_i_and_j & adj_mat(:,i);
        distinct_neighbors_of_j_wrt_i = distinct_neighbors_of_i_and_j & adj_mat(:,j);
        distinct_rel_i = rel_mat(:,i).*distinct_neighbors_of_i_wrt_j;
        Sij_i = sum(distinct_rel_i)/sum(rel_mat(:,i));
        distinct_rel_j = rel_mat(:,j).*distinct_neighbors_of_j_wrt_i;
        Sij_j = sum(distinct_rel_j)/sum(rel_mat(:,j));
        % now common neighbors of i and j
        sum_of_all_rel = sum(rel_mat(:,i)+rel_mat(:,j));
        common_neighbors_of_i_and_j = and(adj_mat(:,i),adj_mat(:,j));
        sum_of_common_rel = sum(common_neighbors_of_i_and_j.*rel_mat(:,i) + common_neighbors_of_i_and_j.*rel_mat(:,j));
        Tij = (sum_of_common_rel / sum_of_all_rel)*adj_mat(i,j);
        %putting value in the two way matrix
        two_way_rel_mat(i,j) = (Sij_i+Sij_j) * (1-Tij) * rel_mat(i,j);
        one_by_two_way_rel_mat(i,j) = 1/two_way_rel_mat(i,j);
    end
end

%% calculating a reward matrix
reward_matrix = zeros(N);
tpm =  rel_mat;
reward_matrix = -range_distance.*one_by_energy_ratio;
reward_matrix = reward_matrix.*one_by_two_way_rel_mat;

for i=1:N
    for j=1:N
        if reward_matrix(i,j) == inf || reward_matrix(i,j) == -inf || reward_matrix(i,j) == 0
            %reward_matrix(i,j) = -inf;
        end
    end
end



for i=1:N
    for j=1:N
        if i==j || reward_matrix(i,j) == 0
            reward_matrix(i,j)= -inf;
        end
        if isnan(reward_matrix(i,j))
            reward_matrix(i,j)= -inf;
        end
    end
end

%% initializing the Q-Table
q_table = reward_matrix;

%% updating the q-table
%so that subsequent updates can iterate the rest entries of table

num_iters = 50; %findMaxIters(adj_mat);
discount_factor = 1;
q_table_temp  = q_table;
max_iterant = -inf;
for iter=1:num_iters
%while (sum(sum(q_table-q_table_temp))<0.00001)
    q_table = q_table_temp;
    for i=1:N
        for j=1:N
            max_iterant = -inf;
            for k=1:N
                if i~=j
                    %max_iterant = (q_table(i,k) + q_table(k,j)*discount_factor);
                    new_iterant = (reward_matrix(i,k) + q_table(k,j)*discount_factor);%*rel_mat(i,j)
                    if max_iterant < new_iterant
                        %disp(i+", "+j+", "+k);
                        max_iterant = new_iterant;
                    end
                end
            end
            if q_table_temp(i,j) < max_iterant
                q_table_temp(i,j) = max_iterant;
            end
        end
    end
end

%% route a message from source to destination

%source_node = coordinates(1,:)
%destination_node = coordinates(N,:)
%current_node = source_node

source_node = 1;
destination_node = N;
current_node = 1;

edd_sd = 0;
path = [source_node];

prob_path = [];

while current_node ~= destination_node && edd_sd<N
    if adj_mat(current_node,destination_node)==1
        c3(isnan(c3))=0;
        prob = 1-(arg/sum(c3));
        prob_path = [prob_path, prob];
        current_node = destination_node;
        edd_sd = edd_sd + 1;
        path = [path current_node];
    else
        c1 = adj_mat(:,current_node)'.*q_table(destination_node,:);
        c2 = reward_matrix(:,current_node).*adj_mat(:,current_node);
        c3 = c1'+c2;
        [arg,argmax] = max(c3);
        %c3(isnan(c3))=0
        %c3 = c3(~isnan(c3))'
        c3(isnan(c3))=0;
        prob = 1-(arg/sum(c3));
        prob_path = [prob_path, prob];
        current_node = argmax;
        edd_sd = edd_sd + 1;
        path = [path current_node];
    end
end


edr_sd = 1;
for i=1:length(path)-1
    edr_sd = edr_sd*rel_mat(path(i),path(i+1))*prob_path(i);
end

[path, "---------", edd_sd, edr_sd];

edr_avg = 0;
edd_avg = 1;
for i=1:length(path)-1
    edr_sd_temp = 1;
    edd_sd_temp = 0;
    for j=i:length(path)-1
        edr_sd_temp = edr_sd_temp*rel_mat(path(j),path(j+1))*prob_path(j);
        edd_sd_temp = edd_sd_temp + 1;
    end
    edr_avg = edr_avg + edr_sd_temp;
    edd_avg = edd_avg + edd_sd_temp;
end
edr_avg = edr_avg / (length(path));
edd_avg = edd_avg / (length(path));

Average_edr_avg_over_mult_runs = Average_edr_avg_over_mult_runs + edr_avg;
Average_edd_avg_over_mult_runs = Average_edd_avg_over_mult_runs + edd_avg;

Average_edr_sd_over_mult_runs = Average_edr_sd_over_mult_runs + edr_sd;
Average_edd_sd_over_mult_runs = Average_edd_sd_over_mult_runs + edd_sd;

%[rounds, edr_avg_over_mult_runs / rounds , edd_avg_over_mult_runs / rounds ]


end

Average_edr_avg_over_mult_runs = Average_edr_avg_over_mult_runs / num_rounds;
Average_edd_avg_over_mult_runs = Average_edd_avg_over_mult_runs / num_rounds; 
Average_edr_sd_over_mult_runs = Average_edr_sd_over_mult_runs / num_rounds;
Average_edd_sd_over_mult_runs = Average_edd_sd_over_mult_runs / num_rounds;

result_for_my_method_quswar = [result_for_my_method_quswar; [N, Average_edr_avg_over_mult_runs, Average_edr_sd_over_mult_runs]]
result_for_my_method2_quswar = [result_for_my_method2_quswar; [N, Average_edd_avg_over_mult_runs, Average_edd_sd_over_mult_runs]]

end