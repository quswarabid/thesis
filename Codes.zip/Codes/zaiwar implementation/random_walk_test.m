function [edr,w,EEd,ed]=random_walk(rel_mat)

% clc
% clear all
% close all

% rel_mat=dlmread('tenth.txt');
N=length(rel_mat);

p=zeros(N);
   
%%

for i=1:N
    i_neib_s=nnz(rel_mat(i,:));
    for j=1:N
        if(rel_mat(i,j)~=0)
            p(i,j)=1/i_neib_s;
        end
    end
end
% p(:,N)=rel_mat(:,N);
p;

v1=p.*rel_mat;
v=v1(1:N-1,1:N-1);
r=v1(1:N-1,N:N);

i=eye(N-1,N-1);
q=i-v;
w=inv(q)*r;
edr=sum(w)/(N-1);
w(1);
%%

Q=p(1:N-1,1:N-1);

one=ones(N-1,1);
ed=inv(i-Q)*one;
EEd=sum(ed)/N-1;
our_ed=ed(1);
EEd;
end

%         
%             
  